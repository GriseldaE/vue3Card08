<template>

  <div>
    
    <user-card
      
      usuario ='aksla'
      correo = 'aksla@hotmail.com'
      biografia = 'Aqui se inesrta la biografia de aksla'
    ></user-card>
  </div>
</template>

<script>
import UserCard from './Comp.vue';

export default {
  components: {
    UserCard,
  },
};
</script>