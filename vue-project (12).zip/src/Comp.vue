

<template>
  <div class="card">
    <div class="card-header">
      <h2>Card</h2>
    </div>
    <div class="card-body">
      <p><strong>Nombre:</strong> {{ usuario }}</p>
      <p><strong>Correo:</strong> {{ correo }}</p>
      <p><strong>Biografia:</strong> {{ biografia }}</p>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    
    usuario: String,
    correo: String,
    biografia: String,
  },
};
</script>

<style scoped>
.card {
  
  margin: 10px;
  padding: 10px;
  border: solid 2px black;
}

.card-header {
  background-color: purple;
  color:azure;
  padding: 1px;
  text-align: justify;
 
}
h2{
padding-left: 40px;
}

.card-body {
  padding: 1px;
}
</style>